# Javascript Rock Paper Scissors
Rock, paper, scissors game made using Javascript

**No installation**

Just open the index file in your browser to play.

![Rock Paper Scissors Example 1](https://user-images.githubusercontent.com/95859352/151275315-25aacc4f-4a2e-4506-9f6d-f5c184ac4990.png)
![Rock Paper Scissors Example 2](https://user-images.githubusercontent.com/95859352/151275324-3874fa0b-1ee9-4f50-afae-8df9cd55ce93.png)
![Rock Paper Scissors Example 3 Rock](https://user-images.githubusercontent.com/95859352/151275327-9892c7d8-cfa3-4fce-837e-e3ea51f61dac.png)
![Rock Paper Scissors Example 4](https://user-images.githubusercontent.com/95859352/151275330-b01322f3-8869-4742-8d0a-63fd51f9a33a.png)
